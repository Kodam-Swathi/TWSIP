import java.util.Scanner;
import java.util.Random;

class GuessGame {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        int r = rand.nextInt(100);
        System.out.println(r);
        System.out.println("---------Welcome to Guess Number---------");
        System.out.println("Level-1");
        System.out.println("guess number between 1-100");
        int attempts = 5;
        int num, i = 0, flag = 0;
        do {
            System.out.println("you have more" + (attempts - i) + " attempts to guess the number");
            num = sc.nextInt();
            if (num < r) {
                System.out.println("number is lower");
            } else if (num > r) {
                System.out.println("number is greater");
            } else if (num == r) {
                System.out.println("Correct Guess!");
                flag = 1;
                System.out.println("Successfully Level-1 Completed");
                break;
            }
            i++;
        } while (i != 5);
        if (flag == 0) {
            System.out.println("THANK YOU!!");
        } else {
            System.out.println("\n\n----------Level-2-----------");
            r = rand.nextInt(500);
            System.out.println(r);
            attempts = 3;
            System.out.println("You have " + attempts + "attempts to complete Level-2");
            System.out.println("Guess number between 1-500");
            i = 0;
            flag=0;
            do {
                System.out.println("you have more" + (attempts - i) + " attempts to guess the number");
                num = sc.nextInt();
                if (num < r) {
                    System.out.println("number is lower");
                } else if (num > r) {
                    System.out.println("number is greater");
                } else if (num == r) {
                    System.out.println("Correct Guess!");
                    flag = 1;
                    System.out.println("--------------You Won!!----------");
                    break;
                }
                i++;
            } while (i != 3);
            if(flag==0)
            {
                System.out.println("You Loss!!");
            }
        }
    }
}