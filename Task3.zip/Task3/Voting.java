import java.util.Scanner;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.AttributeSet.FontAttribute;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
class MyFrame extends JFrame implements ActionListener{
    JLabel heading,nameL,phoneL,castL;
    JTextField nameT,phoneT;
    JPanel panel;
    JRadioButton p1,p2,p3;
    JButton castVote,result;
    int p1count=0,p2count=0,p3count=0;
    MyFrame()
    {
        panel=new JPanel();
        heading=new JLabel("ONLINE VOTING SYSTEM");
        nameL=new JLabel("Username");
        phoneL=new JLabel("Phone Number");
        castL=new JLabel("Cast Your Vote Here");
        nameT=new JTextField(15);
        phoneT=new JTextField(15);
        p1=new JRadioButton("party 1");
        p2=new JRadioButton("party 2");
        p3=new JRadioButton("party 3");
        castVote=new JButton("Submit Vote");
        result=new JButton("check results");
        setLayout(null);
        heading.setBounds(650,200,500,20);
        nameL.setBounds(450, 250, 80, 20);
        nameT.setBounds(550,250,100,20);
        phoneL.setBounds(450, 280, 120, 20);
        phoneT.setBounds(550,280,100,20);
        castL.setBounds(450,310,200,20);
        add(heading);
        add(nameL);
        add(nameT);
        add(phoneL);
        add(phoneT);
        add(castL);
        Border b=BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.red),"Online Voting System",TitledBorder.CENTER,TitledBorder.CENTER);
        // panel.setBorder(b);
        ButtonGroup bg=new ButtonGroup();
        bg.add(p1);
        bg.add(p2);
        bg.add(p3);
        p1.setBounds(450,340,80,20);
        p2.setBounds(450,370,80,20);
        p3.setBounds(450,400,80,20);
        add(p1);
        add(p2);
        add(p3);
        castVote.setBounds(500,500,200,50);
        result.setBounds(800,500,200,50);
        add(castVote);
        add(result);
        castVote.addActionListener(this);
        result.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                checkResult(e);
            }
        });
    }
    public void actionPerformed(ActionEvent e)
    {
        
        if(p1.isSelected())
        {
            p1count++;
            
        }
        else if(p2.isSelected())
        {
            p2count++;
        }
        else if(p3.isSelected())
        {
            p3count++;
            
        }
        else{
            JOptionPane.showMessageDialog(rootPane,"please,select a party");
        }
        nameT.setText("");
        phoneT.setText("");
        p1.setSelected(false);
        p2.setSelected(false);
        p3.setSelected(false);
    }
    public void checkResult(ActionEvent e)
    {
        if(p1count>p2count && p1count>p3count)
        {
            JOptionPane.showMessageDialog(rootPane,"Party 1 is leading");
        }
        else if(p2count>p1count && p2count>p3count)
        {
            JOptionPane.showMessageDialog(rootPane,"Party 2 is leading");
        }
        else if(p3count>p2count && p3count>p1count)
        {
            JOptionPane.showMessageDialog(rootPane,"Party 3 is leading");
        }
    }
}
class Voting{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        MyFrame f=new MyFrame();
        f.setSize(500,500);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}