import java.util.Scanner;
import java.util.Random;
class InvalidLoginExcep extends Exception{
    InvalidLoginExcep(String x)
    {
        super(x);
    }
}
class ATMInterface{
    Scanner sc=new Scanner(System.in);
    String user;
    int pin,balance;
    public void Register()
    {
         System.out.println("enter your name:");
         user=sc.next();
        System.out.println("enter your PIN");
        pin=sc.nextInt();
        Random rand=new Random();
        int acc_no=rand.nextInt()+1000000000;
        System.out.println("Your account number: "+acc_no);
    }
    public void Login()
    {
        try{
            System.out.println("enter your name:");
            String user_log=sc.next();
            System.out.println("enter your PIN");
            int pin_log=sc.nextInt();
            if(user_log.equals(user) && pin_log==pin){
                System.out.println("Login Successfull");
            }
            else{
                throw new InvalidLoginExcep("Invalid username or Login");
            }
        }
        catch (InvalidLoginExcep e){
            System.out.println(e);
        }
    }
    void Deposit()
    {
        System.out.println("enter amount to deposit");
        int dep=sc.nextInt();
        balance+=dep;
        System.out.println("successfully deposited");
    }
    void Withdraw()
    {
        System.out.println("enter amount to Withdraw");
        int withdraw=sc.nextInt();
        if(withdraw>balance)
        {
            System.out.println("InSufficient Balance");
        }
        else
        {
            balance-=withdraw;
            System.out.println("successfully deposited");
        }
    }
    void Transfer()
    {
        System.out.println("enter name:");
        String name=sc.next();
        System.out.println("enter amount to transfer");
        int trans=sc.nextInt();
        balance-=trans;
        System.out.println("successfully transfered");
    }
    void Balance()
    {
        System.out.println("Account Balance: "+balance);
    }
}
public class ATM{
    public static void main(String[] args) {
        ATMInterface ai=new ATMInterface();
        System.out.println("Welcome To ATM");
        System.out.println("1.Register\n 2.exit");
        Scanner sc=new Scanner(System.in);
        int choice=sc.nextInt();
        switch(choice){
            case 1:
                ai.Register();
                System.out.println("\n\n\nLogin To do Transactions");
                ai.Login();
                break;
            // case 2:
            //     ai.Login();
            //     break;
            case 2:
                System.out.println("---THank YOu----");
                break;
        }
        if(choice!=2){
        int ch;
        do{
            System.out.println("\n\n\n1.Deposit\n 2.Withdraw\n 3.Transfer\n4.Balance \n 5.exit");
            ch=sc.nextInt();
            if(ch==1)
            {
                ai.Deposit();
            }
            else if(ch==2)
            {
                ai.Withdraw();
            }
            else if(ch==3)
            {
                ai.Transfer();
            }
            else if(ch==4)
            {
                ai.Balance();
            }
        }while(ch!=5);
        System.out.println("---Thank You Visit Again---");}
    }
}